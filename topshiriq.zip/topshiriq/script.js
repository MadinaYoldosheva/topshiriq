let ozgaruvchi = document.getElementsByClassName('ozgaruvchi')[0];
let amal = document.getElementsByClassName('amal')[0];
let ozgartiruvchi = document.getElementsByClassName('ozgartiruvchi')[0];
let btn = document.getElementsByClassName('btn')[0];
let natija = document.getElementsByClassName('natija')[0];
let murakkabSon=document.getElementById('murakkabSon')
let sonRoyxat = [];
let a = 0;

const hisob = {
    MyFunction() {
        let o1 = parseFloat(ozgaruvchi.value);
        let o2 = parseFloat(ozgartiruvchi.value);
        let operation = amal.value;

        if (operation === '+')
            natija.value = o1 + o2;
        else if (operation === '-')
            natija.value = o1 - o2;
        else if (operation === '/')
            natija.value = o1 / o2;
        else if (operation === '*')
            natija.value = o1 * o2;
        else if (operation === '%')
            natija.value = o1 % o2;

        return natija.value;
    }
};

btn.addEventListener('click', function () {
    let result = hisob.MyFunction(); 
    let natijaValue = parseInt(result); 
    sonRoyxat = [];

   
    for (let i = 1; i <= natijaValue; i++) {
        sonRoyxat.push(i);
    }

    
    a = 0;
    sonRoyxat.forEach(element => {
        if (natijaValue % element === 0) {
            a++;
        }
    });

    
    let miqdor = {
        hisoblash() {
            if (a >= 3)
                // console.log('Murakkab son');
            murakkabSon.textContent='Murakkab son'
            else
                 murakkabSon.textContent='Murakkab son emas' 
        }
    };

    miqdor.hisoblash();
});
